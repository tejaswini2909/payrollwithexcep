package com.cg.payroll.main;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		try {
		PayrollServicesImpl payrollServices=new PayrollServicesImpl();
		int associateId1=payrollServices.acceptAssociateDetails("Teju", "Kuppa", "teju@gmail", "Training", "Analyst", "ak23", 150000,100000,1000,1000,23459,"AvBank","Av23");
		int associateId2=payrollServices.acceptAssociateDetails("Preetham", "Sharma", "preetham@gmail", "Training", "Analyst", "ak83", 190000,120000,1000,1000,23429,"ApBank","Ap24");
		double b=payrollServices.calculateNetSalary(associateId1);
		System.out.println(b);
		System.out.println(payrollServices.getAssociateDetails(associateId1).getSalary().getGratuity());
		System.out.println(payrollServices.calculateNetSalary(associateId2));
		System.out.println(payrollServices.getAssociateDetails(associateId2).getFirstName());
		System.out.println(payrollServices.getAssociateDetails(associateId2).getSalary().getConveyanceAllowance());
	}catch(Exception e) {
		e.printStackTrace();
	}
}
}

		
		//int salValue=30000;
		//String nameToSearch="Teju";
		//Associate associate=searchAssociate(salValue,nameToSearch);
		//if(associate!=null)
			//System.out.println(associate.getFirstName()+" "+associate.getLastName()+" "+associate.getYearlyInvestmentUnder80C());
		//else
			//System.out.println("associate details with Id"+nameToSearch+"Not found");
	//}
		//public static Associate searchAssociate(int yearlyInvestment,String firstName) {
			//Associate[]  associates=new Associate[4];
		// associates[0]=new Associate(212,150000,"Teju","Kuppa","Training","analyst","adk9","teju@gmail",new Salary(2000,400,100,200,500,400,400,20,1200,10000),new BankDetails(234,"Abd","if34"));
		// associates[1]=new Associate(213,160000,"Manisha","Reddy","Training","analyst","adkf9","mani@gmail",new Salary(13000,400,100,20,500,400,400,20,100,1000),new BankDetails(274,"Acd","if94"));
		// associates[2]=new Associate(214,190000,"Avani","Raju","Training","analyst","pfdk9","avani@gmail",new Salary(14000,400,10,200,500,400,400,20,100,1000),new BankDetails(284,"Bhd","if64"));
		 //for(Associate associate:associates) 
			// if(associate!=null&&associate.getFirstName()==firstName&&associate.getYearlyInvestmentUnder80C()>yearlyInvestment&&associate.getSalary().getBasicSalary()>=25000)
				// return associate;
				//return null;
	//	}
//}

