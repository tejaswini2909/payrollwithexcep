package com.cg.payroll.services;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
public class PayrollServicesImpl implements PayrollServices {
	
	private PayrollDAOServices daoServices;
	
	public PayrollServicesImpl() {
		daoServices=new PayrollDAOServicesImpl();
	}
		
			@Override
			public int acceptAssociateDetails(String firstName,String lastName,String emailId,String department,
					String designation,String pancard,int yearlyInvestmentUnder80C,int basicSalary,int epf, 
					 int companyPf,int accountNumber,String bankName,String ifscCode) {
			return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
			}
			public boolean doUpdateAssociate(int associateId,int yearlyInvestmentUnder80C,String firstName, String lastName, 
					String department, String designation, String pancard, String emailId,
					int basicSalary, int epf, int companyPf,
					int accountNumber,String bankName, String ifscCode){
				return daoServices.updateAssociate(new Associate(associateId,yearlyInvestmentUnder80C,firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
			}
		@Override
		public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException{
			double personalAllowance,conveyanceAllowance,otherAllowance,grossSalary,annualSalary,tax,epf,companypf,basicSalary,yearlyInvestmentUnder80C,i,j;
			Associate associate=daoServices.getAssociate(associateId);
			if(associate!=null){
				epf=associate.getSalary().getEpf();
				basicSalary=associate.getSalary().getBasicSalary();
				companypf=associate.getSalary().getCompanyPf();
				yearlyInvestmentUnder80C=associate.getYearlyInvestmentUnder80C();
				personalAllowance=0.3*basicSalary;
				conveyanceAllowance=0.2*basicSalary;
				otherAllowance=0.1*basicSalary;
				grossSalary=basicSalary+(0.25*basicSalary)+personalAllowance+conveyanceAllowance+otherAllowance+companypf;
				annualSalary=grossSalary*12;
				associate.getSalary().setHra((0.25*basicSalary));
				associate.getSalary().setGratuity((0.05*basicSalary));
				associate.getSalary().setConveyanceAllowance(conveyanceAllowance);
				associate.getSalary().setGrossSalary(grossSalary);
				associate.getSalary().setOtherAllowance(otherAllowance);
				associate.getSalary().setPersonalAllowance(personalAllowance);
				j=yearlyInvestmentUnder80C+12*(companypf+epf);	
				if(j>=150000){
					j=150000;
				}		
				if(annualSalary<250000){
					associate.getSalary().setMonthlyTax(0);
					associate.getSalary().setNetSalary((grossSalary-epf-companypf));
					return (grossSalary-epf-companypf);
				}
				else if(annualSalary>=250000&&annualSalary<500000){
					i=(annualSalary-250000-j);
					if(i<=0)
						tax=0;
					else
					tax=(0.1*i)/12;
					associate.getSalary().setMonthlyTax(tax);
					associate.getSalary().setNetSalary((grossSalary-epf-companypf));
					return (grossSalary-epf-companypf-tax);
				}
				else if(annualSalary>=500000&&annualSalary<1000000){
					i=(250000-j)*0.1;
					tax=(((annualSalary-500000)*0.2)+i)/12;
					associate.getSalary().setMonthlyTax(tax);
					associate.getSalary().setNetSalary((grossSalary-epf-companypf));
					return (grossSalary-epf-companypf-tax);
				}
				else if(annualSalary>=1000000){
					i=(250000-j)*0.1;
					tax=(i+100000+((annualSalary-1000000)*0.3))/12;
					associate.getSalary().setMonthlyTax(tax);
					associate.getSalary().setNetSalary((grossSalary-epf-companypf));
					return (grossSalary-epf-companypf-tax);
				}
			}
			return 0;
		}
	
		@Override
		public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
			Associate associate=daoServices.getAssociate(associateId);
			if(associate==null)
				throw new AssociateDetailsNotFoundException("Associate details of"+ associateId+"not found");
			return associate;
		}
		public boolean doDeleteAssociate(int associateId){
			return daoServices.deleteAssociate(associateId);
		}	
		@Override
		public Associate[] getAllAssociatesDetails() {
			return daoServices.getAssociates();
			}
}
