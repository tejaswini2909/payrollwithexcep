package com.cg.eventmanagement.beans;
public class Catering {
	private String cateringStatus,cateringType;
	private int cateringCost;
	private Menu[] menu;
	public Catering() {}
	public Catering(String cateringStatus, String cateringType, int cateringCost, Menu[] menu) {
		super();
		this.cateringStatus = cateringStatus;
		this.cateringType = cateringType;
		this.cateringCost = cateringCost;
		this.menu = menu;
	}
	public String getCateringStatus() {
		return cateringStatus;
	}
	public void setCateringStatus(String cateringStatus) {
		this.cateringStatus = cateringStatus;
	}
	public String getCateringType() {
		return cateringType;
	}
	public void setCateringType(String cateringType) {
		this.cateringType = cateringType;
	}
	public int getCateringCost() {
		return cateringCost;
	}
	public void setCateringCost(int cateringCost) {
		this.cateringCost = cateringCost;
	}
	public Menu[] getMenu() {
		return menu;
	}
	public void setMenu(Menu[] menu) {
		this.menu = menu;
	}
}
