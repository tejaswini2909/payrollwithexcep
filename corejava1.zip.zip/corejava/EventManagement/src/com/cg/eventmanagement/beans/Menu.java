package com.cg.eventmanagement.beans;
public class Menu {
	private String nameOfItem,itemAvailability;
	private int itemCost;
}
