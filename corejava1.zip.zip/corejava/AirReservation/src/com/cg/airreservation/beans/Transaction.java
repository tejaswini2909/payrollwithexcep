package com.cg.airreservation.beans;
public class Transaction {
		private String typeofTransaction,transactionstatus,transactionDate;
		private int transactionamount;
		public Transaction() {}
		public Transaction(String typeofTransaction, String transactionstatus, String transactionDate,
				int transactionamount) {
			super();
			this.typeofTransaction = typeofTransaction;
			this.transactionstatus = transactionstatus;
			this.transactionDate = transactionDate;
			this.transactionamount = transactionamount;
		}
		public String getTypeofTransaction() {
			return typeofTransaction;
		}
		public void setTypeofTransaction(String typeofTransaction) {
			typeofTransaction = typeofTransaction;
		}
		public String getTransactionstatus() {
			return transactionstatus;
		}
		public void setTransactionstatus(String transactionstatus) {
			this.transactionstatus = transactionstatus;
		}
		public String getTransactionDate() {
			return transactionDate;
		}
		public void setTransactionDate(String transactionDate) {
			this.transactionDate = transactionDate;
		}
		public int getTransactionamount() {
			return transactionamount;
		}
		public void setTransactionamount(int transactionamount) {
			this.transactionamount = transactionamount;
		}
}
