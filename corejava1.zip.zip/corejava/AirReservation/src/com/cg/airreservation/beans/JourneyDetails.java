package com.cg.airreservation.beans;
public class JourneyDetails {
	private String from, to, typeOfClass,time;
	private Transaction transactions;
	public JourneyDetails() {}
	public JourneyDetails(String from, String to, String typeOfClass, String time, Transaction transactions) {
		super();
		this.from = from;
		this.to = to;
		this.typeOfClass = typeOfClass;
		this.time = time;
		this.transactions = transactions;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getTypeOfClass() {
		return typeOfClass;
	}
	public void setTypeOfClass(String typeOfClass) {
		this.typeOfClass = typeOfClass;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public Transaction getTransactions() {
		return transactions;
	}
	public void setTransactions(Transaction transactions) {
		this.transactions = transactions;
	}
}