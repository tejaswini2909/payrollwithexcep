package com.cg.airreservation.beans;
public class Flight {
	private String boardingPoint,endingPoint,startTime,reachTime;
	public Passenger passenger;
	public Flight() {}
	public Flight(String boardingPoint, String endingPoint, String startTime, String reachTime, Passenger passenger) {
		super();
		this.boardingPoint = boardingPoint;
		this.endingPoint = endingPoint;
		this.startTime = startTime;
		this.reachTime = reachTime;
		this.passenger = passenger;
	}
	public String getBoardingPoint() {
		return boardingPoint;
	}
	public void setBoardingPoint(String boardingPoint) {
		this.boardingPoint = boardingPoint;
	}
	public String getEndingPoint() {
		return endingPoint;
	}
	public void setEndingPoint(String endingPoint) {
		this.endingPoint = endingPoint;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getReachTime() {
		return reachTime;
	}
	public void setReachTime(String reachTime) {
		this.reachTime = reachTime;
	}
	public Passenger getPassenger() {
		return passenger;
	}
	public void setPassenger(Passenger passenger) {
		this.passenger = passenger;
	}
}