package com.cg.project.services;
public interface MathServices {
	public abstract int add(int n1, int n2);
	public int sub(int n1, int n2);
	 int div(int n1, int n2);
	 }
