package com.cg.inheritance.main;

import com.cg.inheritance.beans.CEmployee;
import com.cg.inheritance.beans.Developer;
import com.cg.inheritance.beans.Employee;
import com.cg.inheritance.beans.PEmployee;
import com.cg.inheritance.beans.Salesmanager;

public class MainClass {

	public static void main(String[] args) {
	PEmployee employee=new PEmployee(1234, 4561, "teju", "kuppa");
	employee.calculateSalary();
	System.out.println(employee.toString());
	CEmployee cemployee=new CEmployee(1235, "teju", "kuppa", 490);
	cemployee.calculateSalary();
	System.out.println(cemployee.toString());
	Developer developer=new Developer(1236, 2345, "teju", "kuppa", 2, 5000);
	developer.calculateSalary();
	System.out.println(developer.toString());
	Salesmanager salesmanager=new Salesmanager(1263, 2000, "Teju", "Kuppa", 20, 10, 30, 300);
	salesmanager.calculateSalary();
	System.out.println(salesmanager.toString());
	Employee emp;
	emp=new PEmployee(544,1000,"teju","kuppa");
	//PEmployee emp1=(PEmployee)emp;
	PEmployee emp=(PEmployee)emp;
	emp.calculateSalary();
	System.out.println(emp.toString());
	//emp1.calculateSalary1();
	//emp.calculateSalary();
	//System.out.println(emp1.toString());
	}
}
