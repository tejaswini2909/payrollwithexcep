package com.cg.inheritance.beans;

public class CEmployee extends Employee{
	private int hrs,variablePay;

	public CEmployee() {
		super();		
	}
	public CEmployee(int employeeId, String firstName, String lastName, int hrs ) {
		super(employeeId, firstName, lastName);
		this.hrs=hrs;
	}

	public CEmployee(int employeeId, int basicSalary, String firstName, String lastName, int hrs, int variablePay ) {
		super(employeeId, basicSalary, firstName, lastName);
		this.hrs=hrs;
		this.variablePay=variablePay;
	}

	public int getHrs() {
		return hrs;
	}

	public void setHrs(int hrs) {
		this.hrs = hrs;
	}

	public int getVariablePay() {
		return variablePay;
	}

	public void setVariablePay(int variablePay) {
		this.variablePay = variablePay;
	}
	public void calculateSalary(){
		this.setVariablePay(hrs*20000);
	}
	@Override
	public String toString() {
		return super.toString()+"CEmployee [hrs=" + hrs + ", variablePay=" + variablePay + "]";
	}
}
