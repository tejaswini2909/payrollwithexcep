package com.cg.inheritance.beans;

public class Developer extends PEmployee{
	private int incentive,projects;

	public Developer() {
		super();
	}

	public Developer(int employeeId, int basicSalary, String firstName, String lastName,int projects, int incentive) {
		super(employeeId, basicSalary, firstName, lastName);
		this.incentive=incentive;
		this.projects=projects;
	}

	public int getIncentive() {
		return incentive;
	}

	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}

	public int getProjects() {
		return projects;
	}

	public void setProjects(int projects) {
		this.projects = projects;
	}
	public void calculateSalary(){
		super.calculateSalary();
		this.setTotalSal(this.getTotalSal()+(this.incentive*this.projects));
	}
	
}
