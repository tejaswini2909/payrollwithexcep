package com.cg.mobilebilling.beans;
public class PostpaidAccount {
			private long mobileNo;
			private Bill[] bills;
			private Plan plans;
			public PostpaidAccount() {
			}
			public PostpaidAccount(int mobileNo, Bill[] bills,Plan plans) {
				
			}
			public PostpaidAccount(long mobileNo, Bill[] bills, Plan plans) {
				super();
				this.mobileNo = mobileNo;
				this.bills = bills;
				this.plans = plans;
			}
			public long getMobileNo() {
				return mobileNo;
			}
			public void setMobileNo(long mobileNo) {
				this.mobileNo = mobileNo;
			}
			public Bill[] getBills() {
				return bills;
			}
			public void setBills(Bill[] bills) {
				this.bills = bills;
			}
			public Plan getPlans() {
				return plans;
			}
			public void setPlans(Plan plans) {
				this.plans = plans;
			}
}
				