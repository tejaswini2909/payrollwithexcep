package com.cg.mobilebilling.beans;
public class Customer {
	private int customerId;
	private long mobileNo;
	private String firstname,lastName,
				emailId,dateOfbirth,adharNo,
				pancardNo;
	private PostpaidAccount[] postpaidaccounts;
	private Address address;
	public Customer() {
	}
	public Customer(int customerId, long mobileNo, String firstname, String lastName, String emailId, String dateOfbirth,
			String adharNo, String pancardNo, PostpaidAccount[] postpaidaccounts,Address address ) {

		super();
		this.customerId = customerId;
		this.mobileNo = mobileNo;
		this.firstname = firstname;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dateOfbirth = dateOfbirth;
		this.adharNo = adharNo;
		this.pancardNo = pancardNo;
		this.postpaidaccounts = postpaidaccounts;
		this.address = address;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDateOfbirth() {
		return dateOfbirth;
	}
	public void setDateOfbirth(String dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}
	public String getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(String adharNo) {
		this.adharNo = adharNo;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public PostpaidAccount[] getPostpaidaccounts() {
		return postpaidaccounts;
	}
	public void setPostpaidaccounts(PostpaidAccount[] postpaidaccounts) {
		this.postpaidaccounts = postpaidaccounts;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
}
		